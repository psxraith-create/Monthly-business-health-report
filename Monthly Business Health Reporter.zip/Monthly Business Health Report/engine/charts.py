# charts.py
import matplotlib.pyplot as plt
import os

def create_charts(sales_df, expense_summary):
    os.makedirs("output/charts", exist_ok=True)

    # Sales Trend
    sales_trend = sales_df.groupby('date')['sale_amount'].sum()
    plt.figure(figsize=(10,5))
    plt.plot(sales_trend.index, sales_trend.values, marker='o', color='blue')
    plt.title("Sales Trend")
    plt.xlabel("Date")
    plt.ylabel("Sales Amount")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("output/charts/sales_trend.png")
    plt.close()

    # Expense Pie Chart
    plt.figure(figsize=(8,6))
    plt.pie(expense_summary['amount'], labels=expense_summary['category'], autopct='%1.1f%%', startangle=140)
    plt.title("Expense Breakdown")
    plt.tight_layout()
    plt.savefig("output/charts/expense_breakdown.png")
    plt.close()
