# core/reason_engine.py
import pandas as pd

def analyze_reasons(df, profit_loss):
    """
    Analyze reasons for profit/loss.
    """
    reasons = {}

    for _, product in profit_loss['product_summary'].iterrows():
        product_name = product['Product']
        profit = product['Profit']
        revenue = product['Revenue']
        cost = product['Total_Cost']
        quantity = product['Quantity']

        # Calculate averages
        avg_selling_price = revenue / quantity
        avg_cost_price = cost / quantity
        margin = (avg_selling_price - avg_cost_price) / avg_selling_price * 100

        insight = f"Product '{product_name}': "

        if profit > 0:
            if margin > 20:
                insight += "High profit margin indicates good pricing strategy."
            elif quantity > df['Quantity'].mean():
                insight += "High sales volume drives profitability despite average margins."
            else:
                insight += "Balanced pricing and volume contribute to profits."
        else:
            if margin < 10:
                insight += "Low profit margin due to high cost prices relative to selling prices."
            elif quantity < df['Quantity'].mean():
                insight += "Low sales volume affects profitability."
            else:
                insight += "High costs are the primary reason for losses."

        reasons[product_name] = insight

    return reasons